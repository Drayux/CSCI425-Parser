echo "#!/bin/bash" > WRECK
echo "python3 wreck.py \$1 \$2" >> WRECK
chmod +x WRECK
source ~khellman/COMPGRADING/setup.sh ~khellman/COMPGRADING